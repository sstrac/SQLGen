import { Component, OnInit, Output } from '@angular/core';
import * as TABLES from '../assets/tables.json'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit{
  tables = TABLES.default.tables

  ngOnInit(){
  }
}
export function isDefined(item): boolean {
  return item !== undefined
}
function makeid(length): string {
  var result = '';
  var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  var charactersLength = characters.length;
  for (var i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
}